# HIP-1613 Use Case Matrix

Quick reference guide for implementing redeemable NFTs across different industries.

## Use Case Comparison Table

| Industry | Use Case | Reserve Type | Redemption Type | Top-Up | Pool | Irrevocable |
|----------|----------|--------------|-----------------|--------|------|-------------|
| **Finance** | Corporate Bond | HBAR + Stablecoin | Full + Burn | No | No | Yes |
| **Finance** | Treasury Share | HBAR | Partial | No | No | Yes |
| **Finance** | Escrow Voucher | HBAR | Full + Burn | No | No | Yes |
| **Gaming** | Loot Box | Bundle | Bundle Redeem | No | No | Optional |
| **Gaming** | Prize Pool | HBAR | Full + Burn | Yes | Yes | No |
| **Gaming** | Season Pass | Token | Partial | No | No | No |
| **Commerce** | Gift Card | HBAR | Partial | Yes | No | Yes |
| **Commerce** | Coupon | HBAR | Full + Burn | No | No | Yes |
| **Commerce** | Store Credit | HBAR/Token | Partial | No | No | No |
| **Loyalty** | Reward Points | Token | Partial | Yes | Yes | No |
| **Loyalty** | Membership Tier | HBAR | Full + Burn | No | No | Yes |
| **Returns** | Return Receipt | HBAR | Partial | No | No | No |
| **Returns** | Refund Claim | HBAR | Full + Burn | No | No | Yes |
| **Events** | Concert Ticket | HBAR | Full + Burn | No | No | Yes |
| **Events** | VIP Pass | HBAR + Token | Partial | Yes | No | Yes |
| **Events** | Merch Bundle | Bundle | Bundle Redeem | No | No | Yes |
| **Supply Chain** | Rental Deposit | HBAR | Partial | No | No | Yes |
| **Supply Chain** | Warranty | HBAR | Full + Burn | No | No | Yes |
| **Supply Chain** | Shipping Insurance | HBAR | Partial | No | No | Yes |
| **RWA** | Tokenized Bond | HBAR + Stablecoin | Full + Burn | No | No | Yes |
| **RWA** | Real Estate Share | HBAR | Partial | No | No | Yes |
| **Carbon** | Carbon Credit | HBAR + Carbon Token | Full + Burn | No | No | Yes |
| **Carbon** | Offset Certificate | HBAR | Full + Burn | No | No | Yes |

---

## Feature Requirements by Use Case

### Financial Instruments (Bonds, Shares, Escrow)
- **Irrevocability**: REQUIRED
- **Multi-asset**: Recommended (HBAR + stablecoin)
- **Expiry**: Optional (maturity date)
- **Transfer restrictions**: Recommended (KYC/compliance)
- **State proofs**: REQUIRED (for audits)

### Gaming (Loot Boxes, Prizes)
- **Irrevocability**: Optional (depends on game economics)
- **Bundles**: REQUIRED for loot boxes
- **Collection pool**: Recommended for jackpots
- **Top-ups**: Recommended (community engagement)
- **Partial redemption**: Optional (staged unlocks)

### Commerce (Coupons, Gift Cards)
- **Irrevocability**: REQUIRED (consumer protection)
- **Partial redemption**: REQUIRED for gift cards
- **Expiry**: Common (promotional periods)
- **Transfer restrictions**: Optional
- **Top-ups**: Optional (reload cards)

### Loyalty Programs
- **Irrevocability**: Not required (flexible balances)
- **Partial redemption**: REQUIRED
- **Collection pool**: Recommended (promotions)
- **Top-ups**: REQUIRED (merchants add value)
- **Multi-asset**: Optional (points + bonus tokens)

### Returns & Refunds
- **Irrevocability**: Situational
- **Partial redemption**: REQUIRED
- **Expiry**: Recommended (return window)
- **State proofs**: REQUIRED (audit trail)
- **Bundles**: Optional (restocking + credit)

### Events & Entertainment
- **Irrevocability**: REQUIRED (refund guarantee)
- **Expiry**: REQUIRED (event date)
- **Bundles**: Optional (merch packages)
- **Collection pool**: Optional (upgrade draws)
- **Transfer restrictions**: Optional (ticket transferability)

### Supply Chain
- **Irrevocability**: REQUIRED (security deposits)
- **Partial redemption**: REQUIRED (damage deductions)
- **Multi-asset**: Optional
- **State proofs**: REQUIRED (logistics tracking)
- **Expiry**: Recommended (rental periods)

### RWA & Carbon
- **Irrevocability**: REQUIRED (regulatory compliance)
- **State proofs**: REQUIRED (retirement/transfer proof)
- **Multi-asset**: Recommended (compliance tokens)
- **Expiry**: Optional (vintage years)
- **Transfer restrictions**: REQUIRED (accredited investors)

---

## Implementation Patterns

### Pattern 1: Simple Coupon
```json
{
  "reserve_spec": {
    "irrevocable": true,
    "initial_balances": [
      {"asset": "HBAR", "amount": 50000000}
    ]
  },
  "partial_policy": {"mode": "PARTIAL_DENY"}
}
```
**Flow**: Mint â†’ Hold â†’ Redeem & Burn

---

### Pattern 2: Gift Card with Reload
```json
{
  "reserve_spec": {
    "irrevocable": true,
    "initial_balances": [
      {"asset": "HBAR", "amount": 100000000}
    ]
  },
  "topup_policy": {
    "mode": "TOPUP_ANY",
    "require_kyc_and_unfrozen": false
  },
  "partial_policy": {
    "mode": "PARTIAL_ALLOW",
    "min_decrement": [{"asset": "HBAR", "amount": 10000000}]
  }
}
```
**Flow**: Mint â†’ Top-up (multiple) â†’ Partial Redeem (multiple) â†’ Full Redeem & Burn

---

### Pattern 3: Community Jackpot
```json
{
  "reserve_spec": {
    "irrevocable": false,
    "initial_balances": [
      {"asset": "HBAR", "amount": 10000000}
    ],
    "collection_pool_participation": true
  },
  "topup_policy": {
    "mode": "TOPUP_ANY",
    "collection_pool_enabled": true,
    "pool_allocation": "POOL_PRO_RATA_BY_RESERVE"
  }
}
```
**Flow**: Mint â†’ Community tops up pool â†’ Redeem (reserve + pool share) & Burn

---

### Pattern 4: Gaming Loot Box
```json
{
  "bundle_spec": {
    "nft_transfers": [
      {"from": "treasury", "token": "weapons", "serial": 123}
    ],
    "fungible_transfers": [
      {"from": "treasury", "token": "gold", "amount": 50000000000}
    ]
  }
}
```
**Flow**: Mint â†’ Hold â†’ Redeem Bundle & Burn

---

### Pattern 5: Carbon Credit Retirement
```json
{
  "reserve_spec": {
    "irrevocable": true,
    "initial_balances": [
      {"asset": "CarbonToken", "amount": 1000000000}
    ],
    "transfer_restricted": true
  },
  "partial_policy": {"mode": "PARTIAL_DENY"}
}
```
**Flow**: Mint â†’ Hold â†’ Redeem & Burn (generates retirement proof)

---

## Decision Tree

**Start Here**: What are you building?

1. **Need to guarantee value?** â†’ `irrevocable = true`
2. **Users spend in parts?** â†’ `partial_policy.mode = PARTIAL_ALLOW`
3. **Others can add value?** â†’ Enable `topup_policy`
4. **Multiple rewards at once?** â†’ Use `BundleSpec`
5. **Community prize pool?** â†’ Enable `collection_pool`
6. **Compliance required?** â†’ Set `transfer_restricted = true`
7. **Time-limited?** â†’ Set `redemption_expiry`

---

## Fee Estimates (Mainnet)

| Operation | Estimated Cost | Notes |
|-----------|----------------|-------|
| Mint with Reserve | ~$0.001 | Per NFT |
| TokenBindReserve | ~$0.001 | Post-mint binding |
| TokenTopUpReserve | ~$0.0001 | Per top-up |
| TokenTopUpCollectionReserve | ~$0.0001 | Pool contribution |
| TokenRedeemAndBurn | ~$0.001 | Full redemption |
| TokenRedeemPartial | ~$0.0005 | Partial withdrawal |
| TokenRedeemForBundle | ~$0.002 | Bundle delivery |

**vs Smart Contracts**: 1,000-10,000x cheaper

---

## Integration Checklist

- [ ] Choose use case pattern from matrix above
- [ ] Define reserve amounts and asset types
- [ ] Configure irrevocability (true for guarantees)
- [ ] Set up partial redemption policy (if needed)
- [ ] Configure top-up policy (if community-funded)
- [ ] Enable collection pool (if jackpot/prize)
- [ ] Set expiry dates (if time-limited)
- [ ] Add transfer restrictions (if compliance needed)
- [ ] Test redemption flows on testnet
- [ ] Generate state proofs for auditors
- [ ] Deploy to mainnet